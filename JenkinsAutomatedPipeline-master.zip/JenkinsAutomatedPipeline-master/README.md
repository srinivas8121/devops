# JenkinsAutomatedPipeline

